# medical_appointment

Time spent: 2 hrs 26 mins 45 secs || contact me: @cybdom (twitter) - contact@cybdom.tech (email)

Buy me coffee => https://www.buymeacoffee.com/bi3cp0Zk5

Results:

<img src="screenshot_1.png" height="480px"> 
<img src="screenshot_2.png" height="480px"> 
<img src="screenshot_3.png" height="480px"> 

Original Design:

<img src="medical_appointment.png" height="480px">

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
